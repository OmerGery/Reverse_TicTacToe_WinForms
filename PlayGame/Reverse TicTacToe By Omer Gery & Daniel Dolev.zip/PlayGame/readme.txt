To Play The Game:
1.click on PlayGame!.exe
2.Enjoy!

For any issues or bugs you may contact : omergery1996@gmail.com or https://github.com/OmerGery
The game was developed by Omer Gery And Daniel Dolev.